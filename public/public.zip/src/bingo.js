var Bingo = {
    questions : [
        {
            check: null,
            num: 0,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 1,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 2,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 3,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 4,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 5,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 6,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 7,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 8,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 9,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 10,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 11,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 12,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 13,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 14,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 15,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 16,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 17,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 18,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 19,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 20,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 21,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 22,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 23,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        },
        {
            check: null,
            num: 24,
            question: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eleifend diam id eros convallis accumsan. Proin porta risus in purus accumsan rutrum. Aliquam rutrum nulla facilisis eros bibendum pulvinar. Nulla ut malesuada mauris, quis egestas diam. Curabitur in felis ut sem condimentum porttitor vitae a nunc. Integer at dolor elit. Vivamus fermentum sed massa ut euismod."
        }
    ]
};
var Team = {
    teams : [
        {
            name: "A",
            score: 0,
            bingoCount: 0,
            teamColor: "#53777A",
            rightQuestions : []
        },
        {
            name: "B",
            score: 0,
            bingoCount: 0,
            teamColor: "#C02942",
            rightQuestions : []
        },
        {
            name: "C",
            score: 0,
            bingoCount: 0,
            teamColor: "#ECD078",
            rightQuestions : []
        }
    ],
    rightQuestion : function(teamNum, questionNum) {
        this.teams[teamNum].rightQuestions.push(questionNum);
        this.teams[teamNum].score += 10;
    }
};
const SIZE = 5;

$(function() {

    // 헤더 초기 세팅
    var teamList = $("#header__team-list");
    var teamScoreItem = "";
    for(var i = 0; i<Team.teams.length; i++) {
        let team = Team.teams[i];
        teamScoreItem +=
            '<li class="item header__team">\
                    <strong class="name">' + team.name + '</strong>\
                    <span id="header-score-' + team.name + '" class="score">score: ' + team.score + '</span>\
                    <span id="header-bingo-' + team.name + '" class="bingo">bingo: ' + team.bingoCount + '</span>\
            </li>';
    }
    teamList.append(teamScoreItem);

    // 빙고 보드 생성
    var cardList = $(".bingo-card");
    var cardItem = "";
    for (var i = 0; i<Bingo.questions.length; i++) {
        let question = Bingo.questions[i];
        cardItem += 
            "<li class='bingo-card__item'>\
                <a id='question-" + question.num + "' class='card__link' href='#modal' data-num=" + question.num + " data-question='question-" + question.question + "'>Modal" + question.num + "</a>\
            </li>";
    }
    cardList.append(cardItem);

    // 팀 선택 라디오 생성
    var btnSelectTeam = $("#radio-btn-team");
    var teamBtnItem = "";
    for(var i = 0; i<Team.teams.length; i++) {
        let team = Team.teams[i];
        teamBtnItem +=
            "<div class='field'>\
                <div class='ui radio checkbox'>\
                    <input type='radio' name='team' value='"+ i + "'/>\
                    <label>" + team.name + "</label>\
                </div>\
            </div>";
    }
    btnSelectTeam.append(teamBtnItem);

    $('.ui.checkbox').checkbox(); // checkbox full features

    $('.card__link').click(function(e){
        let modal = $("#modal");
        let trigger = this.dataset;        
        let questionNum = parseInt(trigger['num']);
        $('.ui.modal').modal({
            onShow: function() {
                let question = trigger['question'];                
                modal.find('.content').text(question);
            },
            onApprove: function() {
                let teamNum = modal.find('input[name=team]:checked').val();
                let team = Team.teams[teamNum];
                setScore(team, questionNum);
            }
        })
        .modal('show');
    });
});

function setScore(team, questionNum) {
    changeColor(team, questionNum);
    rightQuestion(team, questionNum);
    hitBingo(team, questionNum);
    setScoreBoard(team);
}
function changeColor(team, questionNum) {
    $("#question-" + questionNum).css('background-color', team.teamColor);
}
function rightQuestion(team, questionNum) {
    team.rightQuestions.push(questionNum);
    team.score += 10;
}
function hitBingo(team, questionNum) {
    var temp = 0;
    if(isColBingo(team, questionNum)) {
        console.log("Hit Column Bingo!!!");
        temp += 50;
    }
    if(isRowBingo(team, questionNum)) {
        console.log("Hit Row Bingo!!!");
        temp += 50;
    }
    if(isLeftDiaBingo(team, questionNum)) {
        console.log("Hit Diagonal Bingo!!!");
        temp += 50;
    }
    if(isRightDiaBingo(team, questionNum)) {
        console.log("Hit Diagonal Bingo!!!");
        temp += 50;
    }
    team.score += temp;
    for(var i=0; i<Team.teams.length; i++) {
        let temp = Team.teams[i];
        console.log(temp.name + ": " + temp.score);
    }
}
function setScoreBoard(team) {
    var teamScore = $("#header-score-" + team.name);
    var teamBingo = $("#header-bingo-" + team.name);
    console.log(teamScore.text() + "/" + teamBingo.text());
    teamScore.text("score: " + team.score);
    teamBingo.text("bingo: " + team.bingoCount);
}

// 행 검사
function isColBingo(team, questionNum) {
    var col = parseInt(questionNum / SIZE) * SIZE;
    for(var i = col; i < col + SIZE; i++) {
        if(!team.rightQuestions.includes(i)) {
            return false;
        }
    }
    return true;
}
// 열 검사
function isRowBingo(team, questionNum) {
    var row = parseInt(questionNum % SIZE);
    for(var i = row; i <= row + (SIZE-1) * SIZE ; i += SIZE) {
        if(!team.rightQuestions.includes(i)) {
            return false;
        }
    }
    return true;
}

// 대각선 검사
function isLeftDiaBingo(team, questionNum) {
    if(questionNum % (SIZE+1) !== 0) {
        return false;
    }
    for(var i = 0; i < (SIZE+1) * (SIZE); i += (SIZE+1)) {
        if(!team.rightQuestions.includes(i)) {
            return false;
        }
    }
    return true;
}
function isRightDiaBingo(team, questionNum) {
    if(questionNum % (SIZE-1) !== 0) {
        return false;
    }
    if(questionNum === 0 || questionNum === (SIZE * SIZE)-1) {
        return false;
    }
    for(var i = (SIZE-1); i <= (SIZE-1) * (SIZE); i += (SIZE-1)) {        
        if(!team.rightQuestions.includes(i)) {
            return false;
        }
    }
    return true;
}
